export enum UserType {
    ORGANIZATION,
    PERSON
}