export const MONGO_URI = 'mongodb+srv://dbBlank:dbBlankPassword@partyx-db.r9yza.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
export const jwtSecret = 'jwtSecret'